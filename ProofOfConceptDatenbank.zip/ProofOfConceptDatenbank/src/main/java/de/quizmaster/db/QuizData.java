package de.quizmaster.db;

import java.util.List;

/** Ein Quiz mit seinen Fragen (entspricht der Klasse Quiz im Klassendiagramm). */
public record QuizData(int id, int maxPoints, int starsAchieved, List<QuestionData> questions) {
}
