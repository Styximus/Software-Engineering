package de.quizmaster.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Datenschicht von QuizMaster: speichert und laedt Quizzes und NPCs in einer SQLite-Datei.
 * Die Datei wird beim ersten Start automatisch angelegt.
 */
public class QuizMasterDatabase implements AutoCloseable {

    private final Connection connection;

    public QuizMasterDatabase(String file) throws SQLException {
        connection = DriverManager.getConnection("jdbc:sqlite:" + file);
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
        }
        createTables();
    }

    private void createTables() throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.execute("""
                CREATE TABLE IF NOT EXISTS quiz (
                    id             INTEGER PRIMARY KEY,
                    max_points     INTEGER NOT NULL,
                    stars_achieved INTEGER NOT NULL DEFAULT 0
                                   CHECK (stars_achieved BETWEEN 0 AND 3)
                )""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS question (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    quiz_id         INTEGER NOT NULL REFERENCES quiz(id) ON DELETE CASCADE,
                    sort_order      INTEGER NOT NULL,
                    type            TEXT NOT NULL
                                    CHECK (type IN ('MULTIPLE_CHOICE','TEXT','CLOZE','TRUE_FALSE')),
                    format          TEXT NOT NULL,
                    answer          TEXT NOT NULL,
                    question_amount INTEGER
                )""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS npc (
                    id       INTEGER PRIMARY KEY,
                    name     TEXT NOT NULL,
                    role     TEXT NOT NULL,
                    greeting TEXT NOT NULL,
                    pos_x    INTEGER NOT NULL,
                    pos_y    INTEGER NOT NULL,
                    skin     BLOB,
                    quiz_id  INTEGER REFERENCES quiz(id) ON DELETE SET NULL,
                    UNIQUE (pos_x, pos_y)
                )""");
        }
    }

    /** Speichert ein Quiz samt Fragen. Ein vorhandenes Quiz mit gleicher id wird ersetzt. */
    public void saveQuiz(QuizData quiz) throws SQLException {
        connection.setAutoCommit(false);
        try {
            try (PreparedStatement ps = connection.prepareStatement("""
                    INSERT INTO quiz (id, max_points, stars_achieved) VALUES (?, ?, ?)
                    ON CONFLICT(id) DO UPDATE SET
                        max_points = excluded.max_points,
                        stars_achieved = excluded.stars_achieved""")) {
                ps.setInt(1, quiz.id());
                ps.setInt(2, quiz.maxPoints());
                ps.setInt(3, quiz.starsAchieved());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement(
                    "DELETE FROM question WHERE quiz_id = ?")) {
                ps.setInt(1, quiz.id());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement("""
                    INSERT INTO question (quiz_id, sort_order, type, format, answer, question_amount)
                    VALUES (?, ?, ?, ?, ?, ?)""")) {
                int order = 0;
                for (QuestionData q : quiz.questions()) {
                    ps.setInt(1, quiz.id());
                    ps.setInt(2, order++);
                    ps.setString(3, q.type());
                    ps.setString(4, q.format());
                    ps.setString(5, q.answer());
                    if (q.questionAmount() == null) {
                        ps.setNull(6, Types.INTEGER);
                    } else {
                        ps.setInt(6, q.questionAmount());
                    }
                    ps.executeUpdate();
                }
            }
            connection.commit();
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    public Optional<QuizData> loadQuiz(int id) throws SQLException {
        int maxPoints;
        int stars;
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT max_points, stars_achieved FROM quiz WHERE id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                maxPoints = rs.getInt("max_points");
                stars = rs.getInt("stars_achieved");
            }
        }
        List<QuestionData> questions = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement("""
                SELECT type, format, answer, question_amount
                FROM question WHERE quiz_id = ? ORDER BY sort_order""")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int amount = rs.getInt("question_amount");
                    Integer questionAmount = rs.wasNull() ? null : amount;
                    questions.add(new QuestionData(rs.getString("type"), rs.getString("format"),
                            rs.getString("answer"), questionAmount));
                }
            }
        }
        return Optional.of(new QuizData(id, maxPoints, stars, questions));
    }

    /**
     * Speichert einen NPC. Ist die Position schon von einem anderen NPC belegt,
     * wird eine SQLException geworfen (UNIQUE-Regel auf pos_x, pos_y).
     */
    public void saveNpc(NpcData npc) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("""
                INSERT INTO npc (id, name, role, greeting, pos_x, pos_y, skin, quiz_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name = excluded.name, role = excluded.role, greeting = excluded.greeting,
                    pos_x = excluded.pos_x, pos_y = excluded.pos_y,
                    skin = excluded.skin, quiz_id = excluded.quiz_id""")) {
            ps.setInt(1, npc.id());
            ps.setString(2, npc.name());
            ps.setString(3, npc.role());
            ps.setString(4, npc.greeting());
            ps.setInt(5, npc.x());
            ps.setInt(6, npc.y());
            ps.setBytes(7, npc.skin());
            if (npc.quizId() == null) {
                ps.setNull(8, Types.INTEGER);
            } else {
                ps.setInt(8, npc.quizId());
            }
            ps.executeUpdate();
        }
    }

    public Optional<NpcData> loadNpc(int id) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("""
                SELECT name, role, greeting, pos_x, pos_y, skin, quiz_id
                FROM npc WHERE id = ?""")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                int quiz = rs.getInt("quiz_id");
                Integer quizId = rs.wasNull() ? null : quiz;
                return Optional.of(new NpcData(id, rs.getString("name"), rs.getString("role"),
                        rs.getString("greeting"), rs.getInt("pos_x"), rs.getInt("pos_y"),
                        rs.getBytes("skin"), quizId));
            }
        }
    }

    /** true, wenn an dieser Position noch kein NPC steht. */
    public boolean isPositionFree(int x, int y) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT 1 FROM npc WHERE pos_x = ? AND pos_y = ?")) {
            ps.setInt(1, x);
            ps.setInt(2, y);
            try (ResultSet rs = ps.executeQuery()) {
                return !rs.next();
            }
        }
    }

    @Override
    public void close() throws SQLException {
        connection.close();
    }
}
