package de.quizmaster.db;

/**
 * Eine Frage eines Quiz (entspricht den Unterklassen von Question im Klassendiagramm).
 * type: MULTIPLE_CHOICE, TEXT, CLOZE oder TRUE_FALSE
 * answer: bei MULTIPLE_CHOICE die richtigen Antwort-Indizes ("0,2"), sonst die Loesung als Text
 */
public record QuestionData(String type, String format, String answer, Integer questionAmount) {
}
