package de.quizmaster.db;

/**
 * Ein NPC (entspricht der Klasse NPC im Klassendiagramm).
 * skin: PNG-Datei als Bytes, quizId: das Quiz, das der NPC anbietet (kann fehlen).
 */
public record NpcData(int id, String name, String role, String greeting,
                      int x, int y, byte[] skin, Integer quizId) {
}
