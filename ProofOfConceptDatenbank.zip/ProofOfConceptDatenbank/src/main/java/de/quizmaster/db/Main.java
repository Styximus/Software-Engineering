package de.quizmaster.db;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import javax.imageio.ImageIO;

/**
 * Proof of Concept Datenbank: speichert einen NPC mit Quiz in SQLite und laedt ihn wieder.
 * Zweimal starten: beim ersten Mal wird gespeichert, beim zweiten Mal aus der Datei geladen.
 */
public class Main {

    public static void main(String[] args) throws Exception {
        String file = args.length > 0 ? args[0] : "data/quizmaster.db";
        Path parent = Path.of(file).toAbsolutePath().getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }

        try (QuizMasterDatabase db = new QuizMasterDatabase(file)) {
            System.out.println("Datenbank: " + Path.of(file).toAbsolutePath());

            if (db.loadNpc(1).isEmpty()) {
                System.out.println("Keine Daten gefunden -> lege Beispiel-NPC mit Quiz an");
                db.saveQuiz(sampleQuiz());
                db.saveNpc(sampleNpc());
                System.out.println("Gespeichert. Programm erneut starten: Daten werden aus der Datei geladen.");
            } else {
                System.out.println("Daten aus frueherer Sitzung gefunden (Datei wurde nicht neu befuellt)");
            }

            System.out.println();
            printNpc(db);

            System.out.println();
            System.out.println("Test: zweiter NPC auf derselben Position (" + 3 + "," + 4 + ")");
            System.out.println("  Position frei? " + db.isPositionFree(3, 4));
            try {
                db.saveNpc(new NpcData(2, "Doppelgaenger", "Test", "Hallo", 3, 4, null, 1));
                System.out.println("  FEHLER: NPC wurde trotz belegter Position gespeichert");
            } catch (SQLException e) {
                System.out.println("  Abgelehnt: Position belegt");
            }
        }
    }

    private static void printNpc(QuizMasterDatabase db) throws Exception {
        NpcData npc = db.loadNpc(1).orElseThrow();
        System.out.println("NPC geladen:");
        System.out.println("  id=" + npc.id() + ", name=" + npc.name() + ", rolle=" + npc.role());
        System.out.println("  gruss=\"" + npc.greeting() + "\"");
        System.out.println("  position=(" + npc.x() + "," + npc.y() + ")");
        if (npc.skin() != null) {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(npc.skin()));
            System.out.println("  skin=PNG, " + npc.skin().length + " Bytes, "
                    + img.getWidth() + "x" + img.getHeight() + " px");
        }
        Optional<QuizData> quiz = npc.quizId() == null ? Optional.empty() : db.loadQuiz(npc.quizId());
        if (quiz.isPresent()) {
            QuizData q = quiz.get();
            System.out.println("Quiz des NPCs: id=" + q.id() + ", maxPoints=" + q.maxPoints()
                    + ", sterne=" + q.starsAchieved() + ", fragen=" + q.questions().size());
            int i = 1;
            for (QuestionData f : q.questions()) {
                System.out.println("  " + i++ + ". [" + f.type() + "] " + f.format()
                        + "  -> Antwort: " + f.answer());
            }
        }
    }

    private static QuizData sampleQuiz() {
        return new QuizData(1, 3, 0, List.of(
                new QuestionData("MULTIPLE_CHOICE", "Welche Sprachen laufen auf der JVM?", "0,2", 4),
                new QuestionData("TEXT", "Wie heisst die Hauptstadt von Deutschland?", "Berlin", null),
                new QuestionData("TRUE_FALSE", "Java Swing ist eine GUI-Bibliothek.", "true", null)));
    }

    private static NpcData sampleNpc() throws Exception {
        BufferedImage img = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        for (int x = 0; x < 16; x++) {
            for (int y = 0; y < 16; y++) {
                img.setRGB(x, y, new Color(240, 190, 40).getRGB());
            }
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(img, "png", out);
        return new NpcData(1, "Professor Kai", "Informatik-Lehrer",
                "Hallo! Bereit fuer ein Quiz?", 3, 4, out.toByteArray(), 1);
    }
}
