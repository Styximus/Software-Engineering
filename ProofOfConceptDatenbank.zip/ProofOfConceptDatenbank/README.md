# Proof of Concept: Datenbank

Zeigt, dass QuizMaster NPCs und Quizzes dauerhaft in einer SQLite-Datenbank speichern und wieder laden kann.

## Starten

Voraussetzung: JDK 17 oder neuer, Maven (oder IntelliJ mit Maven-Unterstuetzung).

    mvn -q compile exec:java

In IntelliJ: `pom.xml` oeffnen (Open as Project), dann `Main.main()` in `de.quizmaster.db` ausfuehren.
Optional kann als Argument ein anderer Dateipfad fuer die Datenbank uebergeben werden (Standard: `data/quizmaster.db`).

**Zweimal starten:** Beim ersten Start wird ein NPC mit Quiz gespeichert, beim zweiten Start werden die Daten aus der Datei geladen. Das zeigt die dauerhafte Speicherung.

## Tabellen

| Tabelle    | Inhalt                                                          | Entspricht im Klassendiagramm |
|------------|-----------------------------------------------------------------|-------------------------------|
| `quiz`     | id, max_points, stars_achieved                                  | Quiz                          |
| `question` | quiz_id, sort_order, type, format, answer, question_amount      | Question und Unterklassen     |
| `npc`      | id, name, role, greeting, pos_x, pos_y, skin (PNG), quiz_id     | NPC, Position                 |

- Alle Fragetypen liegen in einer Tabelle; `type` unterscheidet MULTIPLE_CHOICE, TEXT, CLOZE und TRUE_FALSE.
- Fragen gehoeren zu einem Quiz (`ON DELETE CASCADE`: wird das Quiz geloescht, verschwinden auch seine Fragen).
- Der NPC verweist auf sein Quiz (`quiz_id`). Wird das Quiz geloescht, bleibt der NPC erhalten.
- `UNIQUE (pos_x, pos_y)`: pro Position nur ein NPC. Das entspricht dem Fall "Position belegt" im Sequenzdiagramm UC-04.

## Schnittstelle fuer die Backend-API

`QuizMasterDatabase`: `saveQuiz`, `loadQuiz`, `saveNpc`, `loadNpc`, `isPositionFree`.
Die Datentypen `QuizData`, `QuestionData`, `NpcData` sind einfache Records. Bei der Integration werden sie auf die Klassen `Quiz`, `Question` und `Npc` abgebildet.

## Grenzen

- Nicht enthalten: Savestate (Sterne, Skins), Import/Export, Loeschen und Auflisten aller NPCs.
- Die Konsolenausgabe verwendet bewusst keine Umlaute, damit sie in jeder Windows-Konsole korrekt angezeigt wird.
