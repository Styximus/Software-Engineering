
package de.quizmaster;

import java.util.List;
import java.util.Arrays;

public class MultipleChoiceQuestion extends Question {

    private List<String> answers;
    private List<Integer> correctIndices;

    public MultipleChoiceQuestion(
            int id,
            String text,
            List<String> answers,
            List<Integer> correctIndices,
            int points,
            String explanation
    ) {
        super(id, text, points);

        if (answers == null || answers.size() < 2
                || correctIndices == null || correctIndices.isEmpty()
                || correctIndices.stream().anyMatch(
                i -> i == null || i < 0 || i >= answers.size())
                || correctIndices.stream().distinct().count()
                != correctIndices.size()) {
            throw new IllegalArgumentException("Ungültige Frage.");
        }

        this.answers = List.copyOf(answers);
        this.correctIndices = List.copyOf(correctIndices);
    }

    public List<String> getAnswers() {
        return answers;
    }

    @Override
    public boolean checkAnswer(String answer) {
        try {
            List<Integer> selected = Arrays.stream(answer.split(","))
                    .map(String::trim)
                    .map(Integer::parseInt)
                    .distinct()
                    .sorted()
                    .toList();

            return selected.equals(
                    correctIndices.stream().sorted().toList()
            );

        } catch (RuntimeException e) {
            return false;
        }
    }

    @Override
    public QuestionType getType() {
        return QuestionType.MULTIPLE_CHOICE;
    }
}
